/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package horadosistema;

import java.util.Date;

/**
 *
 * @author Humberto Desktop
 */
public class HoraDoSistema {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Date data = new Date();
        System.out.println("A hora atual do sistema");
        System.out.println(data.toString());
    }
    
}
